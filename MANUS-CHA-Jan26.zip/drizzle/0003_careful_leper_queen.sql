ALTER TABLE `unmatched_photos` ADD `city` varchar(100);--> statement-breakpoint
ALTER TABLE `unmatched_photos` ADD `state` varchar(100);--> statement-breakpoint
ALTER TABLE `unmatched_photos` ADD `country` varchar(100);